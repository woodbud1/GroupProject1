let avatar = document.getElementById('avatar');
let fullname = document.getElementById('fullname');
let username = document.getElementById('username');
let email = document.getElementById('email');
let city = document.getElementById('city');
let btn = document.getElementById('btn');

function ajax_get(url, callback) {
  var xmlhttp = new XMLHttpRequest();
  xmlhttp.onreadystatechange = function () {
    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
      console.log('responseText:' + xmlhttp.responseText);
      try {
        var data = JSON.parse(xmlhttp.responseText);
      } catch (err) {
        console.log(err.message + " in " + xmlhttp.responseText);
        return;
      }
      callback(data);
    }
  };

  xmlhttp.open("GET", url, true);
  xmlhttp.send();
}

ajax_get('https://api.thedogapi.com/v1/images/search?size=full', function (data) {
  avatar = '<img src="' + data[0]["url"] + '" alt="User Profile Picture" Height="180" Width="180">';
  document.getElementById("avatar").innerHTML = avatar;
});

ajax_get('https://randomuser.me/api/', function (data) {
  fullname.innerHTML = data.results[0].name.first + " " + data.results[0].name.last;
  username.innerHTML = data.results[0].login.username;
  email.innerHTML = data.results[0].email;
  city.innerHTML = data.results[0].location.city;
});

btn.addEventListener("click", function () {
  ajax_get('https://api.thedogapi.com/v1/images/search?size=full', function (data) {
    avatar = '<img src="' + data[0]["url"] + '" alt="User Profile Picture" Height="180" Width="180">';
    document.getElementById("avatar").innerHTML = avatar;
  });

  ajax_get('https://randomuser.me/api/', function (data) {
    fullname.innerHTML = data.results[0].name.first + " " + data.results[0].name.last;
    username.innerHTML = data.results[0].login.username;
    email.innerHTML = data.results[0].email;
    city.innerHTML = data.results[0].location.city;
  });
});